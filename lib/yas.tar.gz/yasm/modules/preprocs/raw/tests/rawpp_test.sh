#! /bin/sh
${srcdir}/out_test.sh rawpp_test modules/preprocs/raw/tests "raw preproc" "-f bin -r raw" ""
exit $?
